module org.gradle.sample {
    exports org.gradle.sample;
}
